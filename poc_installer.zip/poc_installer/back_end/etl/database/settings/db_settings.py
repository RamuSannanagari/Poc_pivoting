
DATABASE ={
    'db_connection':"postgres://guide_user:guide_user123@35.226.209.188:5432/guide_database"
}

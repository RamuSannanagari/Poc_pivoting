<template>
    <section>
        saved workspace home page
    </section>
</template>

<script>
export default {
    data: () => {
        return {

        }
    },
    mounted() {
        console.log("params from main page: ", this.$route.params)
    }
}
</script>
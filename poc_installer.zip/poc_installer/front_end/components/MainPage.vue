<template>
  <section>
    <b-row class="m-0">

      <b-col md="2">
        <b-link href="#" class="btn btn-success mb-2">New WorkSpace</b-link>
        <b-jumbotron bg-variant="info" text-variant="white" class="py-2 px-2">
          <h4>Last Saved</h4>
          <ul>
            <li>ws_project1</li>
            <li>ws_project_2</li>
          </ul>
        </b-jumbotron>
      </b-col>

      <b-col>
         <div class="h2 mb-0">
    <b-icon icon="arrow-up"></b-icon>
    <b-icon icon="exclamation-triangle"></b-icon>
  </div>
      </b-col>
    </b-row>
  </section>
</template>

<template>
  <section class="p-2 Regular section_color  bg-dark position-sticky fixed-top border-bottom">
    <b-row class="m-0">
      <b-col lg="12">
        <h4 class="text-white m-0">Pivot Table</h4>       
      </b-col>
    </b-row>
  </section>
</template>

<style scoped>
.postion-sticky{
  top:0px;
  z-index: 999;
}
.section_color{
  border: 1px solid transparent !important;;
}
</style>